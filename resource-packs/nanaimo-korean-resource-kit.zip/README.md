# 韩服 L7/L8 与宠物资源说明

本文汇总当前资源转换、安装清单和兼容约束。字段与格式定义由知识库04、06、08维护，验证范围由09维护。

## 1. 资源集成范围

### L7：恢复原生外观并保留CN战斗内容

- 引入韩服原生村庄背景、入口、指示牌、加载图、准备房预览。
- `Village_map_image/Village_map_image.pack` 只替换 page18/page19 两条记录，并合并现有道路兼容修复；保留包内其他记录。
- 保留 18↔19，双向封闭 19↔14 的未来关卡连接；保留旧版所需的两项兼容别名。
- **474 个原有 L7 战斗文件逐项保留哈希；另外3份SSTG仅补BGM字段，其他字节不变**。两阶段及兼容别名均引用`23_ssky_game_bgm.ogg`，文件与韩服一致，不替换整关战斗版本。

### L8：选择依赖、转格式、修正关卡身份

- 迁移 ep23 命名族及实际引用的非 ep23 共享依赖，例如 `item_block_stop.mmo`，共享依赖按引用关系登记。
- 两阶段各 9 个真实 SMMO 槽，合计 18 槽。SMMO 按条件选择单槽；stage1 内部保留 `dg01_st00` 命名。
- 韩服 AES 加密的 **MMO300 → CN客户端 MMO200（105 个）**、**PON108 → CN客户端 PON106（48 个）**。解密后按读取器字段布局重序列化，转换输出必须等于配方中的 SHA-256，同时保持字段及事件模型一致。
- 两个 SSTG 的逻辑身份从韩服 `(0,1,stage,0)` 修正为本地 `(0,100,7,stage)`，保留其槽引用。
- 村庄按上面规则合并；其余 EFF/IM3、地图/碰撞、音频等依配方复制或保留CN客户端版本。
- 共校验 **882 个资源文件**：485 `copy`、238 `retain-cn`、105 `mmo200`、48 `pon106`、3 `sstg-l7-bgm`、2 `sstg-l8`、1 `village-pages`。其中 **642 项实际新增/变化**，其余为保留并校验项；另核对上述 474 项 L7 战斗保留清单。
- 共享 eventbox 图及阿梅露文字/效果保留CN客户端内容。

### 宠物：先英雄龙，再按代码差集追加

1. 原CN客户端 868 条 PET → 加入英雄龙 `15003361`（家族 9157）→ 869 条。
2. 再追加韩服差集 **121 条** → **990 条**。合计新增 122 个物品代码，包含共享造型的独立物品。
3. 英雄龙：24 个新增散文件，其中 6 个 PON108→106；保留 27 项共享依赖。
4. 后续 121 条：526 个新增散文件，其中 162 个 PON108→106；保留 486 项共享资源。新依赖输入校验涉及 1011 个韩服散文件。
5. `pi._D7` 采用“解密韩服 CP949 + CN客户端 GBK → 按代码追加 → 本地中文标签 → CN客户端密钥重新加密 → 回读验证”。保持原有行、35 字段布局和成长尾表，增量合并到CN客户端目录。
6. 名称/描述采用项目中文译名；本服人物上限200，122条追加宠物的佩戴要求全部采用韩服原值（三条龙110、英雄龙120、直升机5号15003366为99）。五组熊猫按造型主题意译，攻击数值、槽、价格和成长数值保持原值。英雄龙寿命上限由20调整为50，采用项目耐久政策；期限独立按永久宠物维护，其余宠物沿用原寿命。英雄龙描述攻击922与数值字段915分别维护。
7. **名称最多 15 个 GBK 字节**（16 字节缓冲区包含结尾 NUL）；描述最多 63 字节，路径最多 259 字节。安装器支持旧36行名称修正版的精确迁移；当前配方统一122条追加宠物的中文名称并验证容量。
8. BOO pack 保留CN客户端版本；已选 BOO 记录在CN客户端存在。246 个同名 PON 模型相等但序列化不同，保留CN客户端字节；6 张熊猫贴图有实际差异，也保留CN客户端，避免影响旧宠物。
9. 新增宠物采用三阶造型。GUI 直接指定按适配器的低等级例外和三阶限制执行。

## 2. 涉及哪些资源文件

**逐文件列表以配方和包内 `resource-inventory.tsv` 为准**，下表提供目录概览。TSV 含分组、相对路径、操作、来源 SHA-256、目标/保留 SHA-256 和大小；重复路径可能表示不同模块共同依赖，新增数量按路径去重。

| 范围 | 文件/目录 | 说明 |
|---|---|---|
| 宠物表 | `pi._D7` | 增量合并后的 990 条CN客户端格式表 |
| 宠物弹道 | `flying/pon/` | 英雄龙 6 + 后续 162 个 PON 转换 |
| 宠物效果/贴图 | `effs/game/shootinggamebasic/` | 英雄龙 15 + 后续 295 个文件；含跨 9154/9156 家族引用 |
| 宠物城镇图 | `images/Village_images/pet_images/` | 英雄龙 1 + 后续 23 |
| 宠物战斗图 | `images/game_images/shootinggamebasic/shootingimages/` | 英雄龙 1 + 后续 23 |
| 宠物图标 | `images/shop_images/Icon/pet/` | 英雄龙 1 + 后续 23 |
| L7/L8 村庄包 | `Village_map_image/Village_map_image.pack` | 局部合并，保留其他页面 |
| L7/L8 场景图 | `images/Village_images/`、`effs/village/` | `vill05_gate_ep07*`、`vill05_gate_ep08`、`nanaimo_vill_guidemessage_ru7/ru8` 等 |
| L8 阶段/槽 | `flying/hd0_ep23_dg00_st00.sstg`、`...st01.sstg` 及配方列出的 SMMO | 两阶段及其真实槽 |
| 地形/目标/碰撞 | `flying/map/`、`flying/mmo/`、`images/game_images/shootinggamebasic/coll/` | 按引用加入，按配方维护完整引用 |
| 特效/过场 | `effs/game/shootinggamebasic/`、其 `map/`、`Ending_Event/` | 包含明确引用的共享依赖 |
| 加载与预览 | `images/interface_images/shootingsky_inter_image/` | 实际包含 `dg_intro_hd0_ep23.im3`、`dg_intro_hd0_ep24.im3`、ep22/ep23 preview；名称按配方保留 |
| 音频 | `sounds/` | 配方列出的 8 项（含L7/L8 BGM） |

三份完整安装配方：

- `manifest/hero_dragon_resources.json`
- `manifest/korean_pet_resources.json`（含物品代码、原韩文名、本地标签、阶段、资源和已知未解析引用）
- `manifest/lumineos_resource_port.json`（含韩服输入、CN客户端基线、转换结果、L7 保留项）

构建辅助输入另包含3个共享模型EFF：`ep00_mb_C_man.eff`、`ep00_mb_C_woman.eff`、`ep00_mb_R_00.eff`，位于`effs/game/shootinggamebasic/`，用于确定ep23 MMO引用的EFF行数。辅助输入由`manifest/korean_resource_kit.json`登记，与882项安装输出分别计数。

## 3. 资源包组成

```text
README.md                         本文
resource-inventory.tsv            全量处理/保留清单
kit-manifest.json                 包内每文件大小和 SHA-256
requirements.txt                 构建依赖 pycryptodome
scripts/                         当前转换/安装/打包工具及必要导入模块
manifest/                        三份资源配方 + 构建辅助输入清单
source-kr/                       1905 个去重后的韩服白名单输入
l7-l8-bundle/manifest.json        已转换 L7/L8 包的身份与基线约束
l7-l8-bundle/payload/             882 个已审核输出（含必须校验的共享项）
docs/L7-L8资源移植.md             项目内代码与资源合同说明
```

- `source-kr`提供1905个去重后的转换输入，合计97,843,573字节；其中PET采用韩服格式，按目标CN基线合并。
- L7/L8转换payload合计58,209,798字节，包含882项输出与保留校验项。压缩包大小由生成结果决定。
- 打包内容按三份配方及辅助输入清单选择，在读取和写入时分别核对摘要；包内身份由`kit-manifest.json`及同名SHA-256文件维护。
- 宠物最终表按使用者基线生成，保留原868条、成长尾表及共享资源。
- 资源使用与分发遵循素材授权，项目脚本与客户端素材分别适用各自许可。

## 4. 兼容及验证范围

资源转换需要Python及PyCryptodome；安装、校验、事务回滚使用Python标准库。启动与游戏运行由自包含托管工具负责。精确目录、输入／目标摘要、冲突检测、幂等和回滚构成资源安装契约。

当前验证范围包括格式、字段模型、文件身份、目录构造、安装事务及适配器执行。客户端验收范围为L8两阶段与三难度的显示、声音、碰撞、Boss、结算、续关、返城与多人，以及新增宠物三阶显示和各类攻击。`runtime_accepted`／`runtime_acceptance`保留独立的客户端验收状态。

英雄龙及部分9153–9156 PON保留追踪尾引用`y_ef_smoke_02_t_b.eff`；该依赖列为待确认资源。L7/L8安装器支持持久事务回滚；宠物安装器支持普通异常恢复，完整副本备份承担中断恢复。角色进度采用独立数据库持久化。

客户端EXE补丁的完整应用与回滚步骤统一见[客户端兼容说明](完整适配器与客户端兼容说明.md)。

## 5. 随仓库资源包与安装步骤

`resource-packs/nanaimo-korean-resource-kit.zip`及同目录`.zip.sha256`随main提供，不是仅有清单、下载占位符或Git LFS指针。资源包包含1905项去重韩服输入、882项L7/L8安装输出、三份配方、工具与说明；可供英雄龙24项及其余121条宠物526项新增资源的转换／安装。它**不是完整客户端**：原有CN资源、共享BOO／图像等保留项和原客户端程序仍由合法取得的匹配基础客户端提供。第4节所列待确认尾效果引用仍保留原有边界，不因打包而视为已完成实机验收。

先按仓库README把工程与基础客户端放在同一根目录，并完成启动器的基础兼容准备。退出全部游戏客户端后，在该根目录打开PowerShell。下列命令使用仓库脚本；资源包自身也附有同版工具和配方。不要直接把`source-kr`覆盖到客户端。

已验证的初始868条CN PET表为483152字节，SHA-256为`3efc299b3f30920a0d154d8d3978975995400394d5997521f5e80e48e550638e`。**条目数相同不代表基线相同**；其他未经登记的表不能覆盖成此表来绕过检查。869／990升级输入由`manifest/korean_pet_resources.json`的基线及迁移列表限定。下面先检查表身份再开始写入；已有完整990条安装时跳过英雄龙步骤，直接执行追加宠物迁移与L7/L8安装。

```powershell
$Client = (Get-Location).Path
$Recipe = Get-Content 'manifest/korean_pet_resources.json' -Raw -Encoding UTF8 | ConvertFrom-Json
$KnownPetHashes = @('3efc299b3f30920a0d154d8d3978975995400394d5997521f5e80e48e550638e', $Recipe.baseline_catalog.sha256, $Recipe.installed_catalog.sha256)
$KnownPetHashes += @($Recipe.catalog_migrations | ForEach-Object { $_.before.sha256 })
if ($KnownPetHashes -notcontains (Get-FileHash 'pi._D7' -Algorithm SHA256).Hash) { throw 'PET基线未登记，停止安装，不覆盖原表' }
$Archive = Join-Path $Client 'resource-packs/nanaimo-korean-resource-kit.zip'
$Expected = ((Get-Content -LiteralPath ($Archive + '.sha256') -Raw).Trim() -split '\s+')[0]
if ((Get-FileHash -LiteralPath $Archive -Algorithm SHA256).Hash -ne $Expected) { throw '资源包摘要不匹配' }
$Work = Join-Path $Client ('build/resource-install-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
$Kit = Join-Path $Work 'kit'
Expand-Archive -LiteralPath $Archive -DestinationPath $Kit

python -m pip install pycryptodome
if ($LASTEXITCODE -ne 0) { throw 'Python依赖安装失败' }
python scripts/package_korean_resource_kit.py verify --archive $Archive
if ($LASTEXITCODE -ne 0) { throw '包内文件校验失败' }

python scripts/prepare_hero_dragon.py --source-root "$Kit/source-kr" --client-root $Client --output-root "$Work/hero" --apply
if ($LASTEXITCODE -ne 0) { throw '英雄龙安装失败，保留输出并检查基线' }
python scripts/prepare_korean_pets.py --source-root "$Kit/source-kr" --client-root $Client --output-root "$Work/pets" --apply
if ($LASTEXITCODE -ne 0) { throw '追加宠物安装失败，保留输出并检查基线' }
python scripts/port_lumineos_resources.py apply --bundle "$Kit/l7-l8-bundle" --client $Client
if ($LASTEXITCODE -ne 0) { throw 'L7/L8安装失败，保留事务收据' }

python scripts/prepare_hero_dragon.py --client-root $Client --verify-installed
if ($LASTEXITCODE -ne 0) { throw '英雄龙安装后校验失败' }
python scripts/prepare_korean_pets.py --client-root $Client --verify-installed
if ($LASTEXITCODE -ne 0) { throw '追加宠物安装后校验失败' }
python scripts/port_lumineos_resources.py verify --client $Client
if ($LASTEXITCODE -ne 0) { throw 'L7/L8安装后校验失败' }
```

通过后使用普通GUI启动器进入游戏；启动器继续核对资源凭据并应用对应兼容项。完整安装首次按868→英雄龙869→追加宠物990合并；已登记的869／990目录按精确迁移规则处理，未知基线拒绝，不绕过摘要。已安装旧L7/L8资源包的客户端可直接用本包`apply`升级三处L7音乐字段，无需先回滚整套资源；无需重装已通过校验的宠物模块。

保留`$Work`内备份和客户端的`.openNanaimo-resource-backups`事务收据。L7/L8回滚使用`python scripts/port_lumineos_resources.py rollback --client <客户端目录> --receipt <安装输出的相对收据路径>`；不得把旧备份中的角色存档覆盖回来。其他目录已有后续修改时安装器／回滚器会拒绝。

素材权利归原权利人，随仓库提供不改变原有权利归属或构成原开发方授权。工程代码的许可不自动扩展至该资源包中的游戏素材。
